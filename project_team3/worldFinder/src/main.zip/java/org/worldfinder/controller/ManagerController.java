package org.worldfinder.controller;

public class ManagerController {

}
