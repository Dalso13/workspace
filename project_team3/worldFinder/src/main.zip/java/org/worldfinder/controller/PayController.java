package org.worldfinder.controller;

public class PayController {

}
