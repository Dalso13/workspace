package org.worldfinder.domain;

public class NestedCVO {

}
