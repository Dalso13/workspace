package org.worldfinder.mapper;

public interface UserPostCommentMapper {

}
