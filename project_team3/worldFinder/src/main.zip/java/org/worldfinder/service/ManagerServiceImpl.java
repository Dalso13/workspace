package org.worldfinder.service;

public class ManagerServiceImpl {

}
