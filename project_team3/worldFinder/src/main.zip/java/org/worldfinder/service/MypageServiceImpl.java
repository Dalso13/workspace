package org.worldfinder.service;

public class MypageServiceImpl {

}
