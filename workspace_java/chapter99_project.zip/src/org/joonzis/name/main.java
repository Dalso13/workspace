package org.joonzis.name;

import org.joonzis.status.PlayerStatus;

public class main{
	public static void main(String[] args) {
		
		title t1 = new title();
		t1.name();
		
	}
}
