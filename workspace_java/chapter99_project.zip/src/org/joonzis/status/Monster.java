package org.joonzis.status;



public class Monster {
	
//	public String getName() {
//		return null;};
//	
//	public void setMonsterHp(int hp){};
//	public void setMonsterMp(int mp){};
//	public void setMonsterLevel(int level){};
//	
//	public int neverMonsterHp(){
//		return 0;};
//	public int getMonsterMp(){
//		return 0;};
//	public int getMonsterExp(){
//		return 0;};
//	public int getMonsterLevel(){
//		return 0;};
//	public int getMonsterHp(){
//		return 0;};
//	public int getMonsterMoney(){
//		return 0;};
//	
//	public int getMonsterAttak(){
//		return 0;};
//
//	public int getMonsterAttak_pro(){
//		return 0;};
	
}
