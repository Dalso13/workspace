package org.joonzis.status;
//
//import java.util.Random;
//
public class Skeleton {
//	
//	private String skeletonName;
//	private int skeletonHp;
//	private int skeletonMp;
//	private int skeletonLevel;
//	private int skeletonAttak;
//	private int skeletonAttak_pro;
//	Random ran = new Random();
//	private int skeletonTank;
//	private int skeletonExp;
//	private int skeletonMoney;
//	
//	public Skeleton() {
//		this.skeletonName = "스켈레톤";
//		this.skeletonHp = 300;
//		this.skeletonExp = 150;
//		this.skeletonLevel = 3;
//		
//	}
//
//	@Override
//	public String getName() {
//		return skeletonName;
//	}
//
//	@Override
//	public void setMonsterHp(int hp) {
//		this.skeletonHp = hp;
//		
//	}
//
//	@Override
//	public void setMonsterMp(int mp) {
//		this.skeletonMp = mp;
//		
//	}
//
//	@Override
//	public void setMonsterLevel(int level) {
//		this.skeletonLevel = level;
//		
//	}
//
//	@Override
//	public int neverMonsterHp() {
//		return 300;
//	}
//
//	@Override
//	public int getMonsterMp() {
//		return this.skeletonMp;
//	}
//
//	@Override
//	public int getMonsterExp() {
//		return this.skeletonExp;
//	}
//
//	@Override
//	public int getMonsterLevel() {
//		return this.skeletonExp;
//	}
//
//	@Override
//	public int getMonsterHp() {
//		return this.skeletonHp;
//	}
//
//	@Override
//	public int getMonsterMoney() {
//		ran.setSeed(System.currentTimeMillis());
//		return skeletonMoney = ran.nextInt(40) + 15;
//	}
//
//	@Override
//	public int getMonsterAttak() {
//		int count = (this.skeletonLevel) * 5;
//		ran.setSeed(System.currentTimeMillis());
//		return this.skeletonAttak = ran.nextInt(40 + count) + 25;
//	}
//
//	@Override
//	public int getMonsterAttak_pro() {
//		ran.setSeed(System.currentTimeMillis());
//		return skeletonAttak_pro = ran.nextInt(10) + 1;
//	}
//
//	
//	
//	
}
